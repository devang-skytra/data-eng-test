#!#/usr/bin/python3

#-- Authors    : P Rosario
#-- Modified   :
#---------------------------------------------------------------------------------------------------
#-- Creates a time series of EURUSD exchange rates and saves them on a GCP bucket
#-- Exchange rate sourced from ECB
# USING THE FOREX_PYTHON API
#Documentation:
#https://forex-python.readthedocs.io/
#As a fall back option we will also get prices from the bank of england
#prices available at:
#https://www.bankofengland.co.uk/statistics/exchange-rates
#Code to be run on a daily basis at 8pm London time

import datetime #v3.8.0
from datetime import date
import pandas as pd #v0.25.3
from forex_python.converter import CurrencyRates # v1.5
import google.cloud #v0.34
#from google.cloud import storage
from google.cloud import bigquery
import datalab.storage as gcs #v1.1.5
import io #0.1
from io import StringIO
import requests #v2.16

def fx_load_fx_prices(event, context):
    #Trigger - Cloud Storage bucket - Finalise/Create

    #SOURCE_BUCKET = environ.get('SOURCE_BUCKET', 'SOURCE_BUCKET not set.')
    # THE TRIGGER_FILE IS IN FACT STAT, NOT _SUCCESS, BECAUSE STAT COMES LAST AND IS NEEDED FOR PRE-LOAD CHECKS AGAINST ZstdSerializationError AND FileSplittingError

    TRIGGER_FILE = os.environ.get('TRIGGER_FILE', 'TRIGGER_FILE not set.')
    DEST_BUCKET = os.environ.get('DEST_BUCKET', 'DEST_BUCKET not set.')

    e = event
    bucketName = e['bucket']
    pathNoBucket = e['name']
    #fType = e['contentType']
    #fullpath = e['id']
    #size = e['size']
    #timeCreated = e['timeCreated']

    if TRIGGER_FILE in pathNoBucket:
	    #reads the existing file from the Bucket
	
	    a = (gcs.Bucket('fxrates').item('to/data.csv').read_from())
	    s=str(a,'utf-8')
	    data = StringIO(s)
	    df=pd.read_csv(data)
	    df = df[["Date", "FX"]]
	
	
	    #sets the last date available in the file
	    last_date = df["Date"].max()
	
	    #sets the dates that we are going to look for in the API
	    #list_dates = pd.date_range(start = last_date , end = pd.datetime.today()).to_pydatetime().tolist()
	    list_dates = pd.date_range(start = last_date , end = pd.datetime.today()).to_pydatetime().tolist()
	    date_strings = [dt.strftime("%Y/%m/%d") for dt in list_dates]
	    #as we already have the first date
	    date_strings = date_strings[1:]
	
	    #creates the DataFrame where we will store the results
	    fx_DF = pd.DataFrame()
	    fx_DF["Date"] = date_strings
	    fx_DF["FX"] = 0.0
	
	    #initialises the API Object
	    c = CurrencyRates()
	
	
	    #makes the API calls
	    for i in range(0, len(date_strings)):
	        fx_DF["FX"][i] = c.get_rate('EUR', 'USD', list_dates[i])
	
	    #append the new data to the existing data table
	    fx_DF = df.append(fx_DF)
	
	    #formats the DF to be saved
	    fx_DF = fx_DF.reset_index()
	    fx_DF = fx_DF[["Date", "FX"]].drop_duplicates()
	    fx_DF["Date"] = pd.to_datetime(fx_DF["Date"], format="%Y/%m/%d", errors='coerce')
	    fx_DF = fx_DF.sort_values("Date")
	
	    #loading the data from the bank of england
	    #adapted from here
	    #https://www.datacareer.co.uk/blog/bank-of-england-s-statistical-interactive-database-iadb-using-python/
	
	    url_endpoint = 'http://www.bankofengland.co.uk/boeapps/iadb/fromshowcolumns.asp?csv.x=yes'
	
	    #selects the series to be loaded
	    payload = {
	        'Datefrom'   : '01/Jan/2017',
	        'Dateto'     : '01/Oct/2100',
	        'SeriesCodes': 'XUDLERD',
	        'CSVF'       : 'TN',
	        'UsingCodes' : 'Y',
	        'VPD'        : 'Y',
	        'VFD'        : 'N'
	    }
	
	    #loads the time series
	    response = requests.get(url_endpoint, params=payload)
	    bank_of_england_FX = pd.read_csv(io.BytesIO(response.content))
	
	    # Putting the data in the right format
	    bank_of_england_FX["BOE_FX"] = 1 / bank_of_england_FX["XUDLERD"]
	    bank_of_england_FX = bank_of_england_FX[["DATE","BOE_FX"]]
	    bank_of_england_FX["DATE"] = pd.to_datetime(bank_of_england_FX["DATE"])
	    bank_of_england_FX
	
	    #merge the ECB with the bank of england data
	    fx_DF = pd.merge(fx_DF,bank_of_england_FX, left_on='Date', right_on = "DATE", how = "left")
	    fx_DF = fx_DF[["Date", "FX", "BOE_FX"]]
	
	    #because the bank of england does not publish a value for non trading days, we fill the missing values with the previous working value
	    fx_DF["BOE_FX"].fillna(method='ffill', inplace=True)
	
	    #saves the data in case there's no duplicated dates
	    if fx_DF["Date"].describe()[3] == 1:
	        gcs.Bucket('fxrates').item('to/data.csv').write_to(fx_DF.to_csv(),'text/csv')
	    else:
	        print("there are duplicated dates")
