#!#/usr/bin/python3

import os
from google.cloud import storage
import pandas as pd
from my_pkg.trg_dag import trg_dag

'''
import csv
def readCsvToDict(fName):
    with open(fName) as f:
        csvList = list(csv.reader(f))
        csvDict = {d[0]: d[1] for d in csvList}  # was d[1:] when > 2 elements wide
    return csvDict
print(readCsvToDict('gs://' + fullPath))
'''

#gcf_..._check1 checks ZstdSerializationError, FileSplittingError of TRG_FILE_PATTERN (-c000.csv)
def gcf_bkt_trg_kiwi_stats_check1(event, context):

    TRG_FILE_PATTERN = os.environ.get('TRG_FILE_PATTERN', 'TRG_FILE_PATTERN not set.')

    e = event
    bucketName = e['bucket']
    fullPathNoBucket = e['name']
    fullPath = os.path.join(bucketName, fullPathNoBucket)

    #fType = e['contentType']
    #fullpath = e['id']
    #size = e['size']
    #timeCreated = e['timeCreated']

    if TRG_FILE_PATTERN in fullPathNoBucket:

        #Open up the Stat file and confirm no fundamental issues
        df = pd.read_csv('gs://' + fullPath, index_col = 0, names = ['value'])

        if df.loc['ZstdSerializationError','value'] != 0 or df.loc['FileSplittingError','value'] != 0:
            print('Either ZstdSerializationError is non-zero: ' + str(df.loc['ZstdSerializationError','value']) + ' OR FileSplittingError is non-zero: ' + str(df.loc['FileSplittingError','value']))

        else:

            folderStat = os.path.dirname(fullPathNoBucket)
            #fileStat = os.path.basename(fullPathNoBucket)

            # Determine equivalent Data bucket and path (hour grain)
            folderData = folderStat.replace('Stats', '')
            bucketNameData = bucketName.replace('stat', 'data')
            fileSUCCESS = os.path.join(folderData, '_SUCCESS')

            '''
            print(f"size: {size}")
            print(f"timeCreated: {timeCreated}")
            print(f"pathNoBucket: {pathNoBucket}")
            print(f"fileStat: {fileStat}")
            print(f"pathNoBucketData: {pathNoBucketData}")
            print(f"fileSUCCESS: {fileSUCCESS}")
            '''

            #fileSUCCESS should always exist if TRG_FILE_PATTERN exists but double-check
            storage_client = storage.Client()
            bDest = storage_client.get_bucket(bucketNameData)

            if bDest.blob(fileSUCCESS).exists():

                # get file as blob
                bSrc = storage_client.get_bucket(bucketName)
                f1 = bSrc.blob(fullPathNoBucket)

                # copy to new destination
                statDestFolder = 'STATS_PROCESSED/'
                bSrc.copy_blob(f1, bDest, statDestFolder + fullPathNoBucket)  

                # delete file
                f1.delete()
                # rather than just delete file, delete parent hour grain folder for visual/processing clarity
                hrFolder = os.path.basename(folderStat)
                hrList = bSrc.list_blobs(prefix = hrFolder)
                print('Processing hour folder : ' + hrFolder)
                # unfort, no count or len avail for httpIterator class
                #print('Check hour folder count: ' + str(len(hrList)))
                #for hr in hrList:
                    #print(hr)
                bSrc.delete_blobs(blobs = hrList)
                # double-check they are no other hh folders indicating a previous day was not fully processed and avoid also deleting any additional folders which should be investigated
                #if len(hrList) == 1:
                
                # Finally we can call the AirFlow Dag to do intial process and more detailed Stat Checks before fulling committing to load
                AF_CLI_ID = os.environ.get('AF_CLI_ID', 'AF_CLI_ID not set.')
                AF_WEB_ID = os.environ.get('AF_WEB_ID', 'AF_WEB_ID not set.')
                AF_DAG_NAME = os.environ.get('AF_DAG_NAME', 'AF_DAG_NAME not set.')

                trg_dag(e, AF_CLI_ID, AF_WEB_ID, AF_DAG_NAME)

                #else:
                #print('More than 1 hour folder : ' + hrFolder)
