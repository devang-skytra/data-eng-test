#https://github.com/omidvd79/Big_Data_Demystified/blob/master/airflow/examples/dataproc_create_and_destroy_poc.py

#https://airflow.readthedocs.io/en/stable/_modules/airflow/contrib/operators/dataproc_operator.html

import os
import datetime

from airflow import models
from airflow.contrib.operators.dataproc_operator import DataprocClusterCreateOperator
from airflow.contrib.operators.dataproc_operator import DataProcPySparkOperator
from airflow.contrib.operators.dataproc_operator import DataprocClusterDeleteOperator


yesterday = datetime.datetime.combine( datetime.datetime.today() - datetime.timedelta(1), datetime.datetime.min.time() )

if 1==1:
   project_id = 'prj-sbe'
   cluster_name = 'airflow-spark-transient'  #'airflow-spark-transient-{{ ds_nodash }}'
   num_workers = 2
   zone = 'europe-west2-a'
   storage_bucket = cluster_name
   image_version = '1.4-debian9'
   optional_components = 'ANACONDA,JUPYTER'
   num_masters = 1
   master_machine_type = 'n1-standard-1'
   master_disk_size = 15
   worker_machine_type = 'n1-standard-1'
   worker_disk_size = 15
   idle_delete_ttl = 4000  #just over an hour 3600 secs
   #scopes = 'https://www.googleapis.com/auth/cloud_platform'
   #enable_component_gateway = True

default_dag_args = {
   'start_date': yesterday,
   'retries': 0
}

with models.DAG(
      'Dataproc_DfAPI',
      schedule_interval = None, 
      default_args = default_dag_args) as dag:
   """      
   dataprocClusterCreate = DataprocClusterCreateOperator(
      task_id = 'DataprocCluster.Create',
    	project_id=project_id,
      cluster_name=cluster_name,
      num_workers=num_workers,
      zone=zone,
      storage_bucket=storage_bucket,
      image_version=image_version,
      #optional_components=optional_components,
      num_masters=num_masters,
      master_machine_type=master_machine_type,
      master_disk_size=master_disk_size,
      worker_machine_type=worker_machine_type,
      worker_disk_size=worker_disk_size,
      idle_delete_ttl=idle_delete_ttl
   )
   """

   #https://airflow.readthedocs.io/en/stable/_modules/airflow/contrib/operators/dataproc_operator.html
   # Gave Service account, Dataproc Admin IAM role
   #Actual problem was (?) 'prj_sbe' not 'prj-sbe'
   dataProcPySpark = DataProcPySparkOperator(
      task_id = 'DataProc-PySpark',
      main = f'gs://{storage_bucket}/py/main.py',    #HCFS URI of main .py file.
      cluster_name = cluster_name,
      arguments = None, #Arguments for the job. (templated)
      archives = None,  #List of archived files that will be unpacked in the work
      pyfiles = None,   #List of supported file types: .py, .egg, and .zip
      dataproc_pyspark_properties = None,
      #List jar files to add to driver and tasks. (templated)
      #https://console.cloud.google.com/storage/browser/spark-lib/bigquery
      dataproc_pyspark_jars = f'gs://{storage_bucket}/jars/bigquery_spark-bigquery-latest.jar' 
   )

   #THIS SITE VERY GOOD https://github.com/GoogleCloudPlatform/professional-services/blob/master/examples/cloud-composer-examples/composer_http_post_example/ephemeral_dataproc_spark_dag.py
   """
   submit_pyspark = DataProcPySparkOperator(
      task_id='run_dataproc_pyspark',
      main=PYSPARK_JOB,
      cluster_name='ephemeral-spark-cluster-{{ ds_nodash }}',
      # Let's template our arguments for the pyspark job from the POST payload.
      arguments=["--gcs_path_raw={{ dag_run.conf['raw_path'] }}",
                  "--gcs_path_transformed=gs://" + BUCKET +
                  "/{{ dag_run.conf['transformed_path'] }}"]
   )
   """

   """
   dataprocClusterDelete = DataprocClusterDeleteOperator(
    	task_id = 'DataprocCluster.Delete',
    	cluster_name=cluster_name,
    	project_id=project_id)
   """

   #dataprocClusterCreate >> dataProcPySpark #>> dataprocClusterDelete