import os
import datetime

from airflow import models
from airflow.contrib.operators.dataproc_operator import DataprocClusterCreateOperator


if 1==1:
   project_id = 'prj-sbe'
   cluster_name = 'airflow-spark-transient'  #'airflow-spark-transient-{{ ds_nodash }}'
   num_workers = 2
   zone = 'europe-west2-a'
   storage_bucket = cluster_name
   image_version = '1.4-debian9'
   optional_components = 'JUPYTER'
   #optional_components = 'ANACONDA,JUPYTER'
   num_masters = 1
   master_machine_type = 'n1-standard-1'
   master_disk_size = 15
   worker_machine_type = 'n1-standard-1'
   worker_disk_size = 15
   idle_delete_ttl = 4000  #just over an hour 3600 secs


default_dag_args = {
   'start_date': '2020-01-01',
   'retries': 0
}

with models.DAG(
    'Dataproc_Create',
    schedule_interval = None, 
    default_args = default_dag_args) as dag:

    DataprocClusterCreate = DataprocClusterCreateOperator(
        task_id = 'DataprocCluster-Create',
        project_id=project_id,
        cluster_name=cluster_name,
        num_workers=num_workers,
        zone=zone,
        storage_bucket=storage_bucket,
        image_version=image_version,
        optional_components=optional_components,
        num_masters=num_masters,
        master_machine_type=master_machine_type,
        master_disk_size=master_disk_size,
        worker_machine_type=worker_machine_type,
        worker_disk_size=worker_disk_size,
        idle_delete_ttl=idle_delete_ttl
    )
  